public class Vetor {
    private final double x, y;

    public Vetor(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double modulo() {
        return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    }
}
