
import java.util.Scanner;

public class Main {
 void main(String[] args) {
	  Scanner sc  = new Scanner(System.in);
		Ponto a = new Ponto(sc.nextInt(), sc.nextInt());
		Ponto b = new Ponto(sc.nextInt(), sc.nextInt());
		Quadrado q = new Quadrado(a, b);
		Circunferencia c1 = q.geraCircunferencia();
		System.out.println(c1);
		Circunferencia c2 = new Circunferencia(q);
		System.out.println(c2);
	}

}
