class Ponto {
    private int x, y;

//or:    public Ponto() 		{   _x_ = 0; _y_ = 0;   }
//or:    public Ponto() 		{   setX(0); setY(0);    }
    public Ponto() 		{   this (0, 0);    }

    public Ponto(int x, int y) 	{   setX(x); setY(y);   }

    public int getX() 		{ return x; }
    public int getY() 		{ return y; }

    public void setX(int x) 	{
    	check(x);
    	this.x = x;
    }
    public void setY(int y) 	{
    	check(y);
    	this.y = y;
    }

    private static void check(int x) {
      if (x < 0) {
    		System.err.println("Point.coordinate cannot be negative");
    		System.exit(1);
    	}
    }

    public double dist(Ponto that) {
    		int dx = this.getX() - that.getX();
    		int dy = this.getY() - that.getY();
       	return Math.sqrt(dx*dx+dy*dy);
    }

    public Ponto soma(Ponto that) {
        int x = this.getX() + that.getX();
        int y = this.getY() + that.getY();
        return new Ponto(x, y);
    }

    public Ponto min(Ponto that) {
        int x = Math.min(this.getX(), that.getX());
        int y = Math.min(this.getY(), that.getY();
        return new Ponto(x, y);
    }

    public String toString() {
      return "("+getX() + "," + getY()+")";
    }
}
