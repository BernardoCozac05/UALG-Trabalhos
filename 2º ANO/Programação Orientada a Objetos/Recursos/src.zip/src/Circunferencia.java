public class Circunferencia {
	private Ponto centro;
	private float raio;

	public Circunferencia(Ponto c, float r) {
	   if (r<=0) {
		    System.err.println("ERRO: Circunferencia com raio negativo.");
		    System.exit(1);
	   }
	   centro=c;
	   raio=r;
	}


	public Circunferencia (Quadrado q) {
		Circunferencia tmp = q.geraCircunferencia();
		centro = q.centro;
		ratio = q.raio;
	}

	public String toString() {
		return centro.toString() + "-" + raio;
	}
}
