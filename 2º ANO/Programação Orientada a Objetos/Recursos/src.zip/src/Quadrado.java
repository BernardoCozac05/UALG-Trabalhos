public class Quadrado {
private Ponto origem;
private int lado;

public Quadrado (Ponto A, Ponto B) {
	if (!validaPontos(A, B)) {
		System.err.println("Erro: os pontos "+ A + " e " + B + " nao definem um quadrado");
		System.exit(1);
	}
	origem = A.min(B);
	lado = Math.abs(A.getX()-B.getX());
}

public static boolean validaPontos(Ponto A, Ponto B) {
	int lado1 = Math.abs(A.getX()-B.getX());
	int lado2 = Math.abs(A.getY()-B.getY());
	return lado1 == lado2;
}

public int lado()	{ return this.lado; }
public Ponto origem()	{ return this.origem; }

public Circunferencia geraCircunferencia() {
	float raio = lado / 2.0f;
	Ponto centro = origem.soma(new Ponto((int) raio, (int) raio));
	Circunferencia c = new Circunferencia (centro, raio);
	return c;
}

}
