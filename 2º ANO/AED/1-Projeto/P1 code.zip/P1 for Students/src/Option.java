public class Option {
    

	//TODO: implement
    public Option(int id, String description)
    {
    }

	//TODO: implement
    public int getId()
    {
    }

	//TODO: implement
    public String getDescription()
    {
    }

	//TODO: implement
    @Override
    public boolean equals(Object o)
    {
    }

    public String toString()
    {
    }

    public static Option parseOption(String s) throws NumberFormatException
    {
        /* example of the format of an option when parsing
        + 0. Voltar para trás.
         */
    }
}
