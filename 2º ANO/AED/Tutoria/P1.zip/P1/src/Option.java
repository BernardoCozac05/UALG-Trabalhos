
public class Option {
    

	//TODO: implement
    public Option(int id, String description)
    {
    }

	//TODO: implement
    public int getId()
    {
    	return 0;
    }

	//TODO: implement
    public String getDescription()
    {
    	return "";
    }

	//TODO: implement
    @Override
    public boolean equals(Object o)
    {
    	return false;
    }

    public String toString()
    {
    	return "";
    }

    public static Option parseOption(String s) throws NumberFormatException
    {
        /* example of the format of an option when parsing
        + 0. Voltar para trás.
         */
    	return null;
    }
}
